package com.example.emsb

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ToolItem(
    val id: String = UUID.randomUUID().toString(),
    val categoryName: String,
    val name: String,
    val isIssued: Boolean = false,
    val issuedTo: String? = null,
    val issuedAt: String? = null
)

class StorageManager(context: Context) {
    private val prefs = context.getSharedPreferences("emsb_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()
    fun saveName(v: String) = prefs.edit().putString("storekeeper_name", v).apply()
    fun getName() = prefs.getString("storekeeper_name", "Кладовщик") ?: "Кладовщик"
    fun <T> save(key: String, value: T) = prefs.edit().putString(key, gson.toJson(value)).apply()
    inline fun <reified T> get(key: String): T? {
        val json = prefs.getString(key, null) ?: return null
        return gson.fromJson(json, object : TypeToken<T>() {}.type)
    }
}
private val Bg = Color(0xFF121212)
private val CardBg = Color(0xFF1E1E1E)
private val Yellow = Color(0xFFFFD54F)
private val White = Color.White
private val Gray = Color(0xFFB0B0B0)

@Composable
private fun EMSBTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Yellow, onPrimary = Color.Black, background = Bg,
        surface = CardBg, onSurface = White
    ), content = content)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EMSBTheme { MainScreen() } }
    }
}

private enum class Page(val label: String) {
    HOME("Главное"), TOOLS("Инструмент"), WORKERS("Работники"), ABOUT("Об приложении")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScreen() {
    val context = LocalContext.current
    val storage = remember { StorageManager(context) }
    var keeper by remember { mutableStateOf(storage.getName()) }
    var categories by remember { mutableStateOf(storage.get<List<String>>("categories") ?: emptyList()) }
    var tools by remember { mutableStateOf(storage.get<List<ToolItem>>("tools") ?: emptyList()) }
    var workers by remember { mutableStateOf(storage.get<List<String>>("workers") ?: emptyList()) }
    var page by remember { mutableStateOf(Page.HOME) }
    var category by remember { mutableStateOf<String?>(null) }
    var dialog by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var selectedTool by remember { mutableStateOf<ToolItem?>(null) }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    fun setTools(v: List<ToolItem>) { tools = v; storage.save("tools", v) }
    fun setCategories(v: List<String>) { categories = v; storage.save("categories", v.distinct()) }
    fun setWorkers(v: List<String>) { workers = v; storage.save("workers", v.distinct()) }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = CardBg) {
                Text(keeper, Modifier.fillMaxWidth().clickable { dialog = "keeper"; input = keeper }.padding(20.dp),
                    color = Yellow, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Page.entries.forEach { p ->
                    NavigationDrawerItem(
                        label = { Text(p.label) }, selected = page == p,
                        onClick = { page = p; category = null; scope.launch { drawer.close() } },
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = { Text(category.takeIf { page == Page.TOOLS } ?: page.label, color = Yellow) },
                    navigationIcon = {
                        IconButton(onClick = {
                            if (page == Page.TOOLS && category != null) category = null
                            else scope.launch { drawer.open() }
                        }) {
                            Icon(if (page == Page.TOOLS && category != null) Icons.AutoMirrored.Filled.ArrowBack else Icons.Default.Menu,
                                null, tint = Yellow)
                        }
                    },
                    actions = {
                        if (page == Page.TOOLS || page == Page.WORKERS) {
                            IconButton(onClick = {
                                dialog = if (page == Page.WORKERS) "worker" else if (category == null) "category" else "tool"
                                input = ""
                            }) { Icon(Icons.Default.Add, null, tint = Yellow) }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                when (page) {
                    Page.HOME -> {
                        if (tools.isEmpty()) Empty("Нет инструментов. Добавьте их во вкладке «Инструмент».")
                        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            tools.groupBy { it.categoryName }.forEach { (cat, list) ->
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = CardBg)) {
                                        Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                            Text(cat.uppercase(), color = Yellow, fontWeight = FontWeight.Bold)
                                            Text("Всего: ${list.size} · Выдано: ${list.count { it.isIssued }}", color = Gray)
                                        }
                                    }
                                }
                                items(list, key = { it.id }) { t -> ToolLine(t, { selectedTool = t }, { setTools(tools.filterNot { it.id == t.id }) }) }
                            }
                        }
                    }
                    Page.TOOLS -> if (category == null) {
                        if (categories.isEmpty()) Empty("Нажмите +, чтобы добавить категорию инструмента.")
                        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(categories) { c ->
                                Card(colors = CardDefaults.cardColors(containerColor = CardBg)) {
                                    Row(Modifier.fillMaxWidth().clickable { category = c }.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically) {
                                        Text(c, Modifier.weight(1f), color = White)
                                        Text("${tools.count { it.categoryName == c }} шт.", color = Yellow)
                                        IconButton(onClick = { setCategories(categories.filterNot { it == c }); setTools(tools.filterNot { it.categoryName == c }) }) {
                                            Icon(Icons.Default.Delete, null, tint = Gray)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        val list = tools.filter { it.categoryName == category }
                        if (list.isEmpty()) Empty("В этой категории пока нет инструмента. Нажмите +.")
                        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(list, key = { it.id }) { t -> ToolLine(t, { selectedTool = t }, { setTools(tools.filterNot { it.id == t.id }) }) }
                        }
                    }
                    Page.WORKERS -> if (workers.isEmpty()) Empty("Нажмите +, чтобы добавить работника.")
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(workers) { w ->
                            Card(colors = CardDefaults.cardColors(containerColor = CardBg)) {
                                Row(Modifier.fillMaxWidth().padding(start = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(w, Modifier.weight(1f), color = White)
                                    IconButton(onClick = { setWorkers(workers.filterNot { it == w }) }) { Icon(Icons.Default.Delete, null, tint = Gray) }
                                }
                            }
                        }
                    }
                    Page.ABOUT -> Card(colors = CardDefaults.cardColors(containerColor = CardBg)) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Я АНДРЮША Я АНДРЮША БЕБЕ", color = Yellow, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("ООО ЭМИКС СБ", color = White)
                            Text("Учёт и выдача инструмента", color = Gray)
                        }
                    }
                }
            }
        }
    }

    if (dialog.isNotEmpty()) {
        val title = when (dialog) {
            "keeper" -> "Имя кладовщика"
            "category" -> "Новая категория"
            "tool" -> "Название инструмента"
            else -> "Новый работник"
        }
        AlertDialog(
            onDismissRequest = { dialog = "" },
            containerColor = CardBg,
            title = { Text(title, color = Yellow) },
            text = { OutlinedTextField(value = input, onValueChange = { input = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val v = input.trim()
                    if (v.isNotEmpty()) when (dialog) {
                        "keeper" -> { keeper = v; storage.saveName(v) }
                        "category" -> if (v !in categories) setCategories(categories + v)
                        "tool" -> setTools(tools + ToolItem(categoryName = category ?: "", name = v))
                        "worker" -> if (v !in workers) setWorkers(workers + v)
                    }
                    dialog = ""
                }) { Text("Сохранить", color = Yellow) }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Отмена", color = Gray) } }
        )
    }

    selectedTool?.let { t ->
        AlertDialog(
            onDismissRequest = { selectedTool = null },
            containerColor = CardBg,
            title = { Text(t.name, color = Yellow) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (t.isIssued) Text("Выдан: ${t.issuedTo ?: "—"} · ${t.issuedAt ?: ""}", color = Yellow)
                    else Text("Инструмент свободен", color = Gray)
                    if (!t.isIssued) workers.forEach { worker ->
                        Text(worker, Modifier.fillMaxWidth().clickable {
                            val stamp = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())
                            setTools(tools.map { if (it.id == t.id) it.copy(isIssued = true, issuedTo = worker, issuedAt = stamp) else it })
                            selectedTool = null
                        }.padding(10.dp), color = White)
                    }
                    if (t.isIssued) Text("Вернуть инструмент", Modifier.fillMaxWidth().clickable {
                        setTools(tools.map { if (it.id == t.id) it.copy(isIssued = false, issuedTo = null, issuedAt = null) else it })
                        selectedTool = null
                    }.padding(10.dp), color = Yellow)
                    if (!t.isIssued && workers.isEmpty()) Text("Сначала добавьте работников во вкладке «Работники».", color = Gray)
                }
            },
            confirmButton = { TextButton(onClick = { selectedTool = null }) { Text("Закрыть", color = Gray) } }
        )
    }
}

@Composable
private fun Empty(message: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(message, color = Gray, fontSize = 15.sp)
    }
}

@Composable
private fun ToolLine(tool: ToolItem, onClick: () -> Unit, onDelete: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
                Text(tool.name, color = White, fontWeight = FontWeight.SemiBold)
                Text(if (tool.isIssued) "Выдан: ${tool.issuedTo ?: ""} · ${tool.issuedAt ?: ""}" else "Свободен",
                    color = if (tool.isIssued) Yellow else Gray, fontSize = 13.sp)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = Gray) }
        }
    }
}
