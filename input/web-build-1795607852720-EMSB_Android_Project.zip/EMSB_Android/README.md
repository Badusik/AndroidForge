# EMSB — Android project

Проект Android-приложения для учёта и выдачи инструмента.

## Сборка APK
1. Установите Android Studio.
2. Откройте папку `EMSB_Android` как проект.
3. Дождитесь синхронизации Gradle.
4. Выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

Минимальная версия Android: 6.0 (API 23).
Данные сохраняются локально на устройстве.

Примечание: в среде подготовки нет Android SDK/Gradle, поэтому APK здесь не был собран. Исходный проект подготовлен для открытия и сборки в Android Studio.
